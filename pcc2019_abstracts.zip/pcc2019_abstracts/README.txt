Please fill out the template according to the following steps. 

Step 1: Extract the zip file (if you have not done so yet) and save it to your favorite location. Keep all the files and folders and do not change their names. 

Step 2: Open the file 'template.tex' in the abstracts folder.

 Step 3: Fill out the template. Please do not use any macros, environments, citations, references, footnotes or similar things (just as in abstracts of research articles). Also avoid custom commands and symbols which are not contained in LaTeX or the AMS packages. You can find an example in example.tex (also in the abstracts folder) if you need further help. 

Step 4: Compile the document to see if you did it correctly (it should compile without errors). To do so, you have to compile the file main.tex with pdflatex (again, do not change names and location of other files). 

Step 5: Rename the file 'template.tex' to '[name].tex' (where [name] is replaced by your last name) and send it to bowtell@maths.ox.ac.uk with subject '[name]_PCC2019_abstract'. E.g., if your last name is Doe, name the file 'Doe.tex'. Please do not send us any other files.

 If you have any questions, please write to bowtell@maths.ox.ac.uk.